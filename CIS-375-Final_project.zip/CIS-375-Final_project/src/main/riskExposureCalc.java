package main;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class riskExposureCalc {
    private JPanel RiskExposureCalculator;
    private JTextField LOCAvgComponentTF;
    private JTextField NumOfComponentsTF;
    private JTextField CostOfLOC;
    private JTextField RiskProbTF;
    private JLabel numberOfComponentsFromLabel;
    private JButton calculateButton;
    private JLabel ResultTF;
    private JButton clearButton;
    private JTextField DisplayResult;
    private JLabel LOCOfAvgComponents;
    private JLabel costForEachLOC;
    private JLabel RiskProbability;
    private JLabel title;
    private JButton helpButton;

    public static void main(String[] args) {
        JFrame frame = new JFrame("riskExposureCalc");
        frame.setContentPane(new riskExposureCalc().RiskExposureCalculator);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
        frame.setResizable(false);
    }

    public riskExposureCalc() {
        RiskExposureCalculator.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        DisplayResult.setEditable(false);
        calculateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                calculatingRisk(NumOfComponentsTF.getText());
                calculatingRisk(LOCAvgComponentTF.getText());
                calculatingRisk(CostOfLOC.getText());
                calculatingRisk(RiskProbTF.getText());
                calculatingRiskProbability(RiskProbTF.getText());

                Double numOfComponents = Double.valueOf(NumOfComponentsTF.getText());
                Double locAvgComponents = Double.valueOf(LOCAvgComponentTF.getText());
                Double costOfLOC = Double.valueOf(CostOfLOC.getText());
                Double riskProbability = Double.valueOf(RiskProbTF.getText());
                if (riskProbability < 0 || riskProbability > 1){
                    JOptionPane.showMessageDialog(null, "Please enter a decimal value for risk probability");
                    return;
                }
                Double result = (numOfComponents * locAvgComponents * costOfLOC) * riskProbability;
                if (result > 0){
                    DisplayResult.setText("$" + result.toString());
                }
            }
        });
        clearButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                DisplayResult.setText("");
                NumOfComponentsTF.setText("");
                LOCAvgComponentTF.setText("");
                CostOfLOC.setText("");
                RiskProbTF.setText("");
            }
        });
        helpButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "Contact Information: To contact us, please email us at hsandila@umich.edu\nRisk Exposure Information: \nSample Values:");
            }
        });
    }

    public double calculatingRisk(String str) {
        if (str.isEmpty()){
            JOptionPane.showMessageDialog(null, "Please enter a value for all fields. Click help for more details.");
            return 0;
        }
        try {
            double value = Double.parseDouble(str);
            if (value < 0){
                JOptionPane.showMessageDialog(null, "Please enter a positive value for all fields. Click help for more details.");
            }
            // Use the integer value here
        } catch (NumberFormatException e) {
            // Display an error message
            JOptionPane.showMessageDialog(null, "Please enter a numerical value for all fields. Click help for more details.");
        }
        return 0;
    }
    public double calculatingRiskProbability(String str) {
        try {
            double value = Double.parseDouble(str);
            if (value < 0 || value > 1){
                JOptionPane.showMessageDialog(null, "Please enter a decimal value between 0 and 1");
            }
            // Use the integer value here
        } catch (NumberFormatException e) {
            // Display an error message
            JOptionPane.showMessageDialog(null, "Please enter a valid value");
        }
        return 0;
    }
}
