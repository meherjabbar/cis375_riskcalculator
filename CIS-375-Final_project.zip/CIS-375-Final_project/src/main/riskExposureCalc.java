package main;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class riskExposureCalc {
    //components
    private JPanel RiskExposureCalculator;
    private JTextField LOCAvgComponentTF;
    private JTextField NumOfComponentsTF;
    private JTextField CostOfLOC;
    private JTextField RiskProbTF;
    private JTextField DisplayResult;
    private JButton calculateButton;
    private JButton clearButton;
    private JButton helpButton;
    private JLabel ResultTF;
    private JLabel numberOfComponentsFromLabel;
    private JLabel LOCOfAvgComponents;
    private JLabel costForEachLOC;
    private JLabel RiskProbability;
    private JLabel title;

    public static void main(String[] args) {
        //setting the frame
        JFrame frame = new JFrame("Risk Exposure Calculator");
        frame.setContentPane(new riskExposureCalc().RiskExposureCalculator);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
        frame.setResizable(false);
    }

    public riskExposureCalc() {
        //setting the border design
        RiskExposureCalculator.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        //Users should not be able to change the display result textField, so disable any editing from the user's end
        DisplayResult.setEditable(false);

        // when the calculate button is clicked by the user, get user's input from the textFields, check if they are valid inputs, and perform the risk exposure calculations
        calculateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //get text from the textFields and ensure that the inputs are within valid boundaries
                calculatingRisk(NumOfComponentsTF.getText());
                calculatingRisk(LOCAvgComponentTF.getText());
                calculatingRisk(CostOfLOC.getText());
                calculatingRisk(RiskProbTF.getText());
                calculatingRiskProbability(RiskProbTF.getText());

                //convert all text, which are strings, into doubles to be able to perform calculations
                Double numOfComponents = Double.valueOf(NumOfComponentsTF.getText());
                Double locAvgComponents = Double.valueOf(LOCAvgComponentTF.getText());
                Double costOfLOC = Double.valueOf(CostOfLOC.getText());
                double riskProbability = Double.parseDouble(RiskProbTF.getText());
                //ensure that user enters the risk probability as a percentage
                if (riskProbability < 0 || riskProbability > 1){
                    JOptionPane.showMessageDialog(null, "Please enter a decimal value for risk probability");
                    return;
                }
                //calculate
                double result = (numOfComponents * locAvgComponents * costOfLOC) * riskProbability;
                if (result > 0){
                    DisplayResult.setText("$" + result);
                }
            }
        });
        //when the clear button is clicked, clear all textFields
        clearButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                DisplayResult.setText("");
                NumOfComponentsTF.setText("");
                LOCAvgComponentTF.setText("");
                CostOfLOC.setText("");
                RiskProbTF.setText("");
            }
        });
        //when the help button is clicked, display calculator information, the risk exposure equation, as well as the requirements for each textField input
        helpButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, """
                        CALCULATOR INFORMATION:
                        The risk exposure calculator is used as a cost estimation tool for the risks involved in a software development project.
                        It uses the follow equation:
                        Risk Exposure = (Number of components from scratch * LOC of average component * Cost for each LOC) * Risk probability

                        Here are the bounds for each of the input values:
                            ~Number of components from scratch: positive integer value
                            ~LOC of avg. component: positive integer value
                            ~Cost for each LOC: positive integer value
                            ~Risk probability: positive decimal value from 0-1 (inclusive)

                        CONTACT INFORMATION:
                        To contact us, please email us at hsandila@umich.edu, mjabbar@umich.edu, zjassem@umich.edu, or aqi@umich.edu""");
            }
        });
    }

    public void calculatingRisk(String str) { //ensure that all user inputs are positive, numerical values for all textFields and that there is an input to perform the calculations
        if (str.isEmpty()){
            JOptionPane.showMessageDialog(null, "Please enter a value for all empty fields. Click help for more details.");
            return;
        }
        try {
            double value = Double.parseDouble(str);
            if (value < 0){
                JOptionPane.showMessageDialog(null, "Please enter a positive value for all fields. Click help for more details.");
            }
            // Use the integer value here
        } catch (NumberFormatException e) {
            // Display an error message
            JOptionPane.showMessageDialog(null, "Please enter a numerical value for all fields. Click help for more details.");
        }
    }

    //ensure that risk probability textField is a positive percentage and not empty
    public void calculatingRiskProbability(String str) {
        try {
            double value = Double.parseDouble(str);
            if (value < 0 || value > 1){
                JOptionPane.showMessageDialog(null, "Please enter a decimal value between 0 and 1");
            }
            // Use the integer value here
        } catch (NumberFormatException e) {
            // Display an error message
            JOptionPane.showMessageDialog(null, "Please enter a valid value");
        }
    }
}
