package main;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class riskExposureCalc {
    //components
    private JPanel RiskExposureCalculator;
    private JTextField LOCAvgComponentTF;
    private JTextField NumOfComponentsTF;
    private JTextField CostOfLOC;
    private JTextField RiskProbTF;
    private JTextField DisplayResult;
    private JButton calculateButton;
    private JButton clearButton;
    private JButton helpButton;
    private JLabel ResultTF;
    private JLabel numberOfComponentsFromLabel;
    private JLabel LOCOfAvgComponents;
    private JLabel costForEachLOC;
    private JLabel RiskProbability;
    private JLabel title;

    public static void main(String[] args) {
        JFrame frame = new JFrame("Risk Exposure Calculator"); //object
        frame.setContentPane(new riskExposureCalc().RiskExposureCalculator);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
        frame.setResizable(false);
    }

    public riskExposureCalc() {
        RiskExposureCalculator.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        DisplayResult.setEditable(false);
        calculateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                calculatingRisk(NumOfComponentsTF.getText());
                calculatingRisk(LOCAvgComponentTF.getText());
                calculatingRisk(CostOfLOC.getText());
                calculatingRisk(RiskProbTF.getText());
                calculatingRiskProbability(RiskProbTF.getText());

                Double numOfComponents = Double.valueOf(NumOfComponentsTF.getText());
                Double locAvgComponents = Double.valueOf(LOCAvgComponentTF.getText());
                Double costOfLOC = Double.valueOf(CostOfLOC.getText());
                double riskProbability = Double.parseDouble(RiskProbTF.getText());
                if (riskProbability < 0 || riskProbability > 1){
                    JOptionPane.showMessageDialog(null, "Please enter a decimal value for risk probability");
                    return;
                }
                double result = (numOfComponents * locAvgComponents * costOfLOC) * riskProbability;
                if (result > 0){
                    DisplayResult.setText("$" + Double.toString(result));
                }
            }
        });
        clearButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                DisplayResult.setText("");
                NumOfComponentsTF.setText("");
                LOCAvgComponentTF.setText("");
                CostOfLOC.setText("");
                RiskProbTF.setText("");
            }
        });
        helpButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, """
                        CALCULATOR INFORMATION:
                        The risk exposure calculator is used as a cost estimation tool for the risks involved in a software development project.
                        It uses the follow equation:
                        Risk Exposure = (Number of components from scratch * LOC of average component * Cost for each LOC) * Risk probability

                        Here are the bounds for each of the input values:
                            ~Number of components from scratch: positive integer value
                            ~LOC of avg. component: positive integer value
                            ~Cost for each LOC: positive integer value
                            ~Risk probability: positive decimal value from 0-1 (inclusive)

                        CONTACT INFORMATION:
                        To contact us, please email us at hsandila@umich.edu, mjabbar@umich.edu, zjassem@umich.edu, or aqi@umich.edu""");
            }
        });
    }

    public void calculatingRisk(String str) {
        if (str.isEmpty()){
            JOptionPane.showMessageDialog(null, "Please enter a value for all fields. Click help for more details.");
            return;
        }
        try {
            double value = Double.parseDouble(str);
            if (value < 0){
                JOptionPane.showMessageDialog(null, "Please enter a positive value for all fields. Click help for more details.");
            }
            // Use the integer value here
        } catch (NumberFormatException e) {
            // Display an error message
            JOptionPane.showMessageDialog(null, "Please enter a numerical value for all fields. Click help for more details.");
        }
    }
    public void calculatingRiskProbability(String str) {
        try {
            double value = Double.parseDouble(str);
            if (value < 0 || value > 1){
                JOptionPane.showMessageDialog(null, "Please enter a decimal value between 0 and 1");
            }
            // Use the integer value here
        } catch (NumberFormatException e) {
            // Display an error message
            JOptionPane.showMessageDialog(null, "Please enter a valid value");
        }
    }
}
